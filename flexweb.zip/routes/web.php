<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth/login');
});

Auth::routes();

Route::middleware(['auth'])->group(function () {
    
    Route::get('/', function () {
        return view('layouts.backend.contentdemo');
    })->name('dash.index'); 
	Route::get('/config/admins', 'UsuarioController@listAdmins')->name('config.listadmin');
	Route::get('/config/users', 'UsuarioController@listUsers')->name('config.listuser');
	Route::post('/config/admins/add', 'UsuarioController@createUser')->name('config.adduser');
    Route::get('/config/users/reset/{id}', 'UsuarioController@resetUsers')->name('config.resetuser');  
    Route::get('/config/users/block/{id}', 'UsuarioController@blockUsers')->name('config.blockuser');
    Route::get('/config/users/reset_pass', 'UsuarioController@reset_pass')->name('config.resetpass');
    Route::put('/config/users/update_pass', 'UsuarioController@update_pass')->name('config.updatepass');
    Route::delete('/config/users/delete/{id}', 'UsuarioController@deleteUser')->name('config.deleteUser');
    Route::put('/config/users/update/{id}', 'UsuarioController@updateUsers')->name('config.updateUsers');

    Route::get('/informe/vendedores', 'InformesController@inf_vendedores')->name('informe.vendedores');
    Route::post('/informe/vendedor/', 'InformesController@inf_dataVen')->name('informe.vendedor');
    //Route::get('/config/admins/add', 'UsuarioController@createUser')->name('config.adduser');
    

    Route::get('/informe/pivot', 'InformesController@pivot')->name('informe.pivot');


}); 