            <footer class="footer">
                <div class="container-fluid">
                    <nav class="pull-left">

                    </nav>
                    <a href="http://sisfan.cl/" target="_blank" style="color:red">
                        <p class="copyright pull-right" style="color:red">
                            &copy;
                         Sisfan 
                            <script>
                                document.write(new Date().getFullYear())
                            </script>                         
                        </p>
                    </a>       
<!--                                 
                    <p class="copyright pull-right">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                        <a href="#">Sisfan</a>, Desarrollado en Chile.
                    </p>
-->                    
                </div>
            </footer>